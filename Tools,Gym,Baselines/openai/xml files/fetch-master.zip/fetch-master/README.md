# Fetch
Mujoco Models for Fetch Robot

# Environments 

fetch_pole.xml           |  fetch_maneuver.xml       |teleOp_boxes.xml             | teleOp_objects.xml          
:-------------------------:|:-------------------------:|:-------------------------:|:-------------------------:
![Alt text](gallery/pole.JPG?raw=false "Fetch Pole") |  ![Alt text](gallery/maneuver.JPG?raw=false "fetch maneuver") | ![Alt text](gallery/boxes.JPG?raw=false "teleOp Boxes") | ![Alt text](gallery/objects.JPG?raw=false "teleOp objects")



# TeleOp Video
([Click to play](https://www.youtube.com/watch?v=2qEf5TkFXpQ))

[![TeleOp](https://img.youtube.com/vi/2qEf5TkFXpQ/0.jpg)](https://www.youtube.com/watch?v=2qEf5TkFXpQ)
